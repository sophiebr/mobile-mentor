package edu.rosehulman.brusniss.mobilementor.profile.ui

import android.support.v4.app.Fragment

class ProfileFragment : Fragment() {
}